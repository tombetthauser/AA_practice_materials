# Write a method that returns b^n recursively. Your solution should accept 
# negative values for n.

def exponent(b, n)

end
