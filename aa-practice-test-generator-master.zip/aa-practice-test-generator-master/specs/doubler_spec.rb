describe "#doubler" do
  subject(:array) { [1, 2, 3] }

  it "doubles the elements of the array" do
    expect(doubler(array)).to eq([2, 4, 6])
  end

  it "does not modify the original array" do
    duped_array = array.dup
    doubler(array)
    
    expect(array).to eq(duped_array)
  end
end
