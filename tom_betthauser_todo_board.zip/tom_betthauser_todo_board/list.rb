require_relative "./item.rb"


class List

  def initialize(label)
    @label = label
    @items = []
  end

  def label=(new_label)
    @label = new_label
  end

  def add_item(title, deadline, description)
    new_item = Item.new(title, deadline, description = "")
    @items << new_item if new_item
    @items.include?(new_item)
  end

  def size
    @items.length
  end

  def valid_index?(index)
    index > -1 && index < @items.length
  end

  def swap(idx1, idx2)
    return false unless self.valid_index?(idx1) && self.valid_index?(idx2)
    @items[idx1], @items[idx2] = @items[idx2], @items[idx1]
    true
  end

  def [](idx)
    @items[idx]
  end

  def priority
    @items.first
  end

end